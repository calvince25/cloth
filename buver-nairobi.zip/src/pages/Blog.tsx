import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import { BLOG_POSTS } from '@/data';
import { Button } from '@/components/ui/button';

export default function Blog() {
  return (
    <div className="pb-20">
      <Helmet>
        <title>Fashion Blog | Buver Nairobi</title>
        <meta name="description" content="Latest fashion trends, style tips, and news from Nairobi's favorite clothing store." />
      </Helmet>

      <div className="bg-gray-50 py-20 border-b border-gray-100">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-5xl font-serif font-bold mb-6">Our Blog</h1>
          <p className="text-gray-500 max-w-md mx-auto">
            Stay updated with the latest trends and style guides from the heart of Nairobi.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {BLOG_POSTS.map(post => (
            <article key={post.id} className="group">
              <Link to={`/blog/${post.slug}`} className="block aspect-video overflow-hidden mb-6">
                <img
                  src={post.image}
                  alt={post.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
              </Link>
              <div className="flex items-center gap-4 text-xs uppercase tracking-widest text-primary font-bold mb-4">
                <span>Fashion</span>
                <span className="w-1 h-1 rounded-full bg-gray-300" />
                <span className="text-gray-500 font-medium">{new Date(post.date).toLocaleDateString('en-KE', { month: 'long', day: 'numeric', year: 'numeric' })}</span>
              </div>
              <Link to={`/blog/${post.slug}`} className="hover:text-primary transition-colors">
                <h2 className="text-3xl font-serif font-bold mb-4 leading-tight">{post.title}</h2>
              </Link>
              <p className="text-gray-600 mb-6 leading-relaxed">
                {post.excerpt}
              </p>
              <Link to={`/blog/${post.slug}`}>
                <Button variant="link" className="p-0 text-secondary font-bold uppercase tracking-widest text-xs hover:text-primary">
                  Read More
                </Button>
              </Link>
            </article>
          ))}
        </div>
      </div>
    </div>
  );
}
