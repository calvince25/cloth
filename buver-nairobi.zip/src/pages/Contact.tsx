import { Helmet } from 'react-helmet-async';
import { Mail, Phone, MapPin, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

export default function Contact() {
  return (
    <div className="pb-20">
      <Helmet>
        <title>Contact Us | Buver Nairobi</title>
        <meta name="description" content="Get in touch with Buver Nairobi. We're here to help with your orders and inquiries." />
      </Helmet>

      <div className="bg-secondary text-white py-24">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-5xl font-serif font-bold mb-6">Get In Touch</h1>
          <p className="text-gray-400 max-w-md mx-auto">
            Have a question about an order or want to know more about our collection? We'd love to hear from you.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 -mt-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Contact Info Cards */}
          <div className="bg-white p-8 shadow-lg border border-gray-100 flex flex-col items-center text-center">
            <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-6">
              <Phone className="w-6 h-6 text-primary" />
            </div>
            <h3 className="text-lg font-bold mb-2">Call Us</h3>
            <p className="text-gray-500 mb-4">Available Mon-Sat, 9am-6pm</p>
            <a href="tel:+254700000000" className="text-secondary font-bold hover:text-primary">+254 700 000 000</a>
          </div>

          <div className="bg-white p-8 shadow-lg border border-gray-100 flex flex-col items-center text-center">
            <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-6">
              <MessageCircle className="w-6 h-6 text-primary" />
            </div>
            <h3 className="text-lg font-bold mb-2">WhatsApp</h3>
            <p className="text-gray-500 mb-4">Fastest response time</p>
            <a href="https://wa.me/254700000000" target="_blank" rel="noopener noreferrer" className="text-secondary font-bold hover:text-primary">Chat with us</a>
          </div>

          <div className="bg-white p-8 shadow-lg border border-gray-100 flex flex-col items-center text-center">
            <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-6">
              <Mail className="w-6 h-6 text-primary" />
            </div>
            <h3 className="text-lg font-bold mb-2">Email Us</h3>
            <p className="text-gray-500 mb-4">For general inquiries</p>
            <a href="mailto:hello@buver.co.ke" className="text-secondary font-bold hover:text-primary">hello@buver.co.ke</a>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 mt-20 items-start">
          {/* Contact Form */}
          <div>
            <h2 className="text-3xl font-serif font-bold mb-8">Send us a Message</h2>
            <form className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-widest font-bold">Full Name</label>
                  <Input placeholder="John Doe" className="rounded-none h-12" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-widest font-bold">Email Address</label>
                  <Input type="email" placeholder="john@example.com" className="rounded-none h-12" />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs uppercase tracking-widest font-bold">Subject</label>
                <Input placeholder="Inquiry about order #1234" className="rounded-none h-12" />
              </div>
              <div className="space-y-2">
                <label className="text-xs uppercase tracking-widest font-bold">Message</label>
                <textarea 
                  className="w-full min-h-[150px] p-4 border border-input focus:ring-2 focus:ring-primary outline-none transition-all"
                  placeholder="How can we help you?"
                />
              </div>
              <Button className="w-full bg-secondary hover:bg-secondary/90 text-white rounded-none h-14 uppercase tracking-widest">
                Send Message
              </Button>
            </form>
          </div>

          {/* Location & Map */}
          <div>
            <h2 className="text-3xl font-serif font-bold mb-8">Our Location</h2>
            <div className="space-y-6 mb-8">
              <div className="flex gap-4">
                <MapPin className="w-6 h-6 text-primary shrink-0" />
                <div>
                  <h4 className="font-bold mb-1">Nairobi Headquarters</h4>
                  <p className="text-gray-600">CBD, Kenyatta Avenue, Nairobi, Kenya</p>
                  <p className="text-gray-500 text-sm mt-2">Serving Westlands, Kilimani, Lavington, and nationwide.</p>
                </div>
              </div>
            </div>
            {/* Mock Map Placeholder */}
            <div className="aspect-video bg-gray-100 flex items-center justify-center border border-gray-200">
              <div className="text-center p-8">
                <MapPin className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-400 italic">Interactive Map Loading...</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
