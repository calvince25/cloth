import { useState, useMemo } from 'react';
import { Helmet } from 'react-helmet-async';
import { PRODUCTS } from '@/data';
import ProductCard from '@/components/ProductCard';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';

interface ShopProps {
  category?: 'women' | 'men' | 'kids';
  filter?: 'new' | 'sale';
}

export default function Shop({ category, filter }: ShopProps) {
  const [activeSubCategory, setActiveSubCategory] = useState<string | null>(null);

  const filteredProducts = useMemo(() => {
    let result = PRODUCTS;
    
    if (category) {
      result = result.filter(p => p.category === category);
    }
    
    if (filter === 'new') {
      result = result.filter(p => p.isNew);
    } else if (filter === 'sale') {
      result = result.filter(p => p.isSale);
    }
    
    if (activeSubCategory) {
      result = result.filter(p => p.subCategory === activeSubCategory);
    }
    
    return result;
  }, [category, filter, activeSubCategory]);

  const subCategories = useMemo(() => {
    const cats = PRODUCTS
      .filter(p => !category || p.category === category)
      .map(p => p.subCategory);
    return Array.from(new Set(cats));
  }, [category]);

  const pageTitle = category 
    ? `${category.charAt(0).toUpperCase() + category.slice(1)}'s Collection` 
    : filter === 'sale' ? 'Sale' : filter === 'new' ? 'New Arrivals' : 'All Collection';

  return (
    <div className="pb-20">
      <Helmet>
        <title>{pageTitle} | Buver Nairobi</title>
        <meta name="description" content={`Shop the latest ${pageTitle} at Buver Nairobi. Fast delivery and M-Pesa payments.`} />
      </Helmet>

      {/* Header */}
      <div className="bg-gray-50 py-16 border-b border-gray-100">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-serif font-bold mb-4">{pageTitle}</h1>
          <p className="text-gray-500 max-w-md mx-auto">
            Discover our curated selection of premium {category || 'fashion'} pieces.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 mt-12">
        <div className="flex flex-col lg:flex-row gap-12">
          {/* Sidebar Filters */}
          <aside className="w-full lg:w-64 shrink-0">
            <div className="sticky top-24">
              <h3 className="text-sm uppercase tracking-widest font-bold mb-6">Categories</h3>
              <div className="flex flex-wrap lg:flex-col gap-2">
                <Button
                  variant="ghost"
                  className={cn(
                    "justify-start rounded-none px-4 py-2 h-auto text-sm",
                    !activeSubCategory ? "bg-gray-100 font-bold" : "text-gray-500"
                  )}
                  onClick={() => setActiveSubCategory(null)}
                >
                  All {category || 'Items'}
                </Button>
                {subCategories.map(cat => (
                  <Button
                    key={cat}
                    variant="ghost"
                    className={cn(
                      "justify-start rounded-none px-4 py-2 h-auto text-sm",
                      activeSubCategory === cat ? "bg-gray-100 font-bold" : "text-gray-500"
                    )}
                    onClick={() => setActiveSubCategory(cat)}
                  >
                    {cat}
                  </Button>
                ))}
              </div>

              <Separator className="my-8" />

              <h3 className="text-sm uppercase tracking-widest font-bold mb-6">Price Range</h3>
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <input type="checkbox" id="p1" className="accent-primary" />
                  <label htmlFor="p1" className="text-sm text-gray-600">Under KES 3,000</label>
                </div>
                <div className="flex items-center gap-2">
                  <input type="checkbox" id="p2" className="accent-primary" />
                  <label htmlFor="p2" className="text-sm text-gray-600">KES 3,000 - KES 7,000</label>
                </div>
                <div className="flex items-center gap-2">
                  <input type="checkbox" id="p3" className="accent-primary" />
                  <label htmlFor="p3" className="text-sm text-gray-600">Over KES 7,000</label>
                </div>
              </div>
            </div>
          </aside>

          {/* Product Grid */}
          <div className="flex-grow">
            <div className="flex justify-between items-center mb-8">
              <p className="text-sm text-gray-500">Showing {filteredProducts.length} products</p>
              <select className="bg-transparent border-none text-sm font-medium focus:ring-0 cursor-pointer">
                <option>Sort by: Newest</option>
                <option>Price: Low to High</option>
                <option>Price: High to Low</option>
                <option>Most Popular</option>
              </select>
            </div>

            {filteredProducts.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-12">
                {filteredProducts.map(product => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            ) : (
              <div className="text-center py-20">
                <p className="text-gray-500 italic">No products found in this category.</p>
                <Button 
                  variant="link" 
                  className="mt-4 text-primary"
                  onClick={() => setActiveSubCategory(null)}
                >
                  Clear all filters
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
